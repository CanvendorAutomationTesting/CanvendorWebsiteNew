package pageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Contact_Page_Page_Objects {
	@FindBy(xpath = "//a[text()='Contact']")
	public static WebElement contactPageObjects;

	@FindBy(xpath ="//input[@id='name']")
	public static WebElement inputName;

	@FindBy(xpath ="//input[@name='email']")
	public static WebElement inputEmail;

	@FindBy(xpath ="//input[@name='subject']")
	public static WebElement inputSubject;

	@FindBy(xpath = "//textarea[@name='message']")
	public static WebElement inputMessage;
	
	@FindBy(xpath ="//button[text()='Send Messages']")
	public static WebElement clickSendMessageBtn;

}
