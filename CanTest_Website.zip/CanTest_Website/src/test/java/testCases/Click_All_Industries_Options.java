package testCases;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import commonActions.CommonFunctions;
import pageObject.Industries_Page_Page_Objects;

public class Click_All_Industries_Options extends CommonFunctions {
	@Test
	public void clickIndustriesBtn() throws InterruptedException {
		PageFactory.initElements(driver,Industries_Page_Page_Objects.class);
		Industries_Page_Page_Objects.ClickIndustries.click();
		Thread.sleep(2000);

		PageFactory.initElements(driver,Industries_Page_Page_Objects.class);
		Industries_Page_Page_Objects.clickManufacturing.click();

		Industries_Page_Page_Objects.ClickIndustries.click();

		PageFactory.initElements(driver,Industries_Page_Page_Objects.class);
		Industries_Page_Page_Objects.clickAutomotive.click();
		Thread.sleep(2000);
		Industries_Page_Page_Objects.ClickIndustries.click();


		PageFactory.initElements(driver,Industries_Page_Page_Objects.class);
		Industries_Page_Page_Objects.clickBanking.click();
		Thread.sleep(2000);
		Industries_Page_Page_Objects.ClickIndustries.click();

		PageFactory.initElements(driver,Industries_Page_Page_Objects.class);
		Industries_Page_Page_Objects.clickCommunication.click();

		Industries_Page_Page_Objects.ClickIndustries.click();
		Thread.sleep(2000);
		PageFactory.initElements(driver,Industries_Page_Page_Objects.class);
		Industries_Page_Page_Objects.clickHealthCare.click();

		Industries_Page_Page_Objects.ClickIndustries.click();
		Thread.sleep(2000);
		PageFactory.initElements(driver,Industries_Page_Page_Objects.class);
		Industries_Page_Page_Objects.clickInsurance.click();
		

	}

}
