package testCases;





import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import commonActions.CommonFunctions;
import pageObject.Contact_Page_Page_Objects;


public class Contact_Page_InputDetails extends CommonFunctions {

	@Test
	@Parameters({"name","email","subject","message"})           
	public void contactInput(String name,String email,String subject,String message) throws InterruptedException  {
		PageFactory.initElements(driver,Contact_Page_Page_Objects.class);
		Contact_Page_Page_Objects.contactPageObjects.click();

		Contact_Page_Page_Objects.inputName.sendKeys(name);
		
		Contact_Page_Page_Objects.inputEmail.sendKeys(email);
		
		Contact_Page_Page_Objects.inputSubject.sendKeys(subject);
		
		Contact_Page_Page_Objects.inputMessage.sendKeys(message); 
		
//		Contact_Page_Page_Objects.clickSendMessageBtn.click();
		
//		Home_Page_Page_Objects.homePageObjects.click();
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("window.scrollBy(250, 250)", "");
//		Thread.sleep(2000);
//		Home_Page_Page_Objects.clickGetInTouch.click();
	}
}
