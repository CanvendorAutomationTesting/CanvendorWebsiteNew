package testCases;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import commonActions.CommonFunctions;
import pageObject.Careers_Page_Page_Objects;

public class Click_Careers_Page_Input extends CommonFunctions{

	@Test
	public void clickCareers() throws InterruptedException {

		PageFactory.initElements(driver,Careers_Page_Page_Objects.class);
		Careers_Page_Page_Objects.careersPageObjects.click();
		Thread.sleep(2000);
		Careers_Page_Page_Objects.clickJoinUs.click();
		Thread.sleep(2000);
	}

}
